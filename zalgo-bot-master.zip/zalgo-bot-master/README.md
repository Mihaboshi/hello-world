# Zalgo Bot
A Slack bot that uglifies your message with a bunch of unicode characters

If Zalgo Bot is in the channel, type 'zalgo' followed by your message
